<?php
/**
 * MewsCenter — API data sensor (SQLite)
 *
 * Endpoint:
 *   GET  api/sensor.php?action=latest                 -> generate data simulasi s/d sekarang, kembalikan data terbaru
 *   GET  api/sensor.php?action=history&limit=100      -> riwayat data (default source=dummy)
 *        &source=dummy|mqtt
 *   POST api/sensor.php?action=store  (body JSON)     -> simpan data asli dari MQTT (source=mqtt)
 *
 * Simulasi disesuaikan dengan kondisi Lampahan Timur, Bener Meriah (±1.200 mdpl),
 * musim kemarau: suhu sejuk 16–28 °C, tekanan stasiun ±880 hPa, hujan jarang.
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
date_default_timezone_set('Asia/Jakarta');

const SIM_INTERVAL = 15;     // detik antar data simulasi
const MAX_BACKFILL = 100;    // titik maksimum yang diisi ketika ada jeda (halaman lama tidak dibuka)
const RETENTION_DAYS = 30;     // data lebih lama dari ini dihapus
const DB_FILE = __DIR__ . '/../data/mews.sqlite';
const FIELDS = [
    'temp',
    'humidity',
    'pressure',
    'wind_speed',
    'wind_direction',
    'rain',
    'rain_rate',
    'flood',
    'soil_moisture',
    'pitch',
    'roll',
    'lux',
    'uv',
    'battery',
];

// ===== DATABASE =====
function db(): PDO
{
    $dir = dirname(DB_FILE);
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
        file_put_contents($dir . '/.htaccess', "Require all denied\n");
    }
    $pdo = new PDO('sqlite:' . DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_TIMEOUT, 5);
    $pdo->exec('PRAGMA journal_mode = WAL');

    $cols = implode(', ', array_map(fn($f) => "$f REAL", FIELDS));
    $pdo->exec("CREATE TABLE IF NOT EXISTS readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL,
        source TEXT NOT NULL DEFAULT 'dummy',
        $cols
    )");
    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_readings_source_ts ON readings(source, ts)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)');
    return $pdo;
}

function metaGet(PDO $pdo, string $key): ?array
{
    $st = $pdo->prepare('SELECT v FROM meta WHERE k = ?');
    $st->execute([$key]);
    $v = $st->fetchColumn();
    return $v === false ? null : json_decode($v, true);
}

function metaSet(PDO $pdo, string $key, array $value): void
{
    $pdo->prepare('INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v')
        ->execute([$key, json_encode($value)]);
}

function insertReading(PDO $pdo, int $ts, string $source, array $vals): void
{
    $cols = implode(', ', FIELDS);
    $ph = implode(', ', array_fill(0, count(FIELDS), '?'));
    $args = [$ts, $source];
    foreach (FIELDS as $f) {
        $args[] = isset($vals[$f]) && is_numeric($vals[$f]) ? (float) $vals[$f] : null;
    }
    $pdo->prepare("INSERT INTO readings (ts, source, $cols) VALUES (?, ?, $ph)")->execute($args);
}

function formatRow(array $row): array
{
    $out = [
        'ts' => date('c', (int) $row['ts']),
        'source' => $row['source'],
        'sid' => $row['source'] === 'dummy' ? 'Local' : 'ESP32-S3',
    ];
    foreach (FIELDS as $f) {
        $out[$f] = $row[$f] === null ? null : (float) $row[$f];
    }
    return $out;
}

// ===== SIMULATOR =====
function gauss(float $sigma = 1.0): float
{
    $u = max(mt_rand() / mt_getrandmax(), 1e-9);
    $v = mt_rand() / mt_getrandmax();
    return sqrt(-2 * log($u)) * cos(2 * M_PI * $v) * $sigma;
}

function rnd(float $min, float $max): float
{
    return $min + (mt_rand() / mt_getrandmax()) * ($max - $min);
}

function clamp(float $v, float $min, float $max): float
{
    return max($min, min($max, $v));
}

/** Kurva harian 0..1 — minimum sekitar 06:00, maksimum sekitar 14:30. */
function diurnal(float $h, float $minH = 6.0, float $maxH = 14.5): float
{
    if ($h >= $minH && $h < $maxH) {
        return (1 - cos(M_PI * ($h - $minH) / ($maxH - $minH))) / 2;
    }
    $span = 24 - ($maxH - $minH);
    $d = fmod($h - $maxH + 24, 24);
    // pangkat < 1 -> pendinginan lebih cepat di sore/awal malam
    return (1 + cos(M_PI * ($d / $span) ** 0.6)) / 2;
}

/** Faktor matahari 0..1 — terbit ±06:35, terbenam ±18:40 WIB (Aceh). */
function sunFactor(float $h): float
{
    $rise = 6.6;
    $set = 18.65;
    if ($h <= $rise || $h >= $set)
        return 0.0;
    return sin(M_PI * ($h - $rise) / ($set - $rise));
}

function initialState(): array
{
    return [
        'tempN' => 0.0,
        'humN' => 0.0,
        'presN' => 0.0,
        'windN' => 0.0,
        'wdir' => rnd(180, 260),
        'cloud' => 0.3,
        'rainLeft' => 0,
        'rainRate' => 0.0,
        'rainDay' => '',
        'rainTotal' => 0.0,
        'flood' => 0.6,
        'soil' => 42.0,
        'battery' => 85.0,
        'pitchBase' => 0.42,
        'rollBase' => -0.18,
    ];
}

function simulate(array &$s, int $ts, int $dt): array
{
    $h = (int) date('G', $ts) + (int) date('i', $ts) / 60 + (int) date('s', $ts) / 3600;
    $d = diurnal($h);
    $sun = sunFactor($h);
    $k = $dt / 3600; // fraksi jam

    // Tutupan awan — musim kemarau, rata-rata cerah berawan (~0.3)
    $s['cloud'] = clamp($s['cloud'] + (0.3 - $s['cloud']) * 0.02 + gauss(0.03), 0, 1);

    // Hujan — jarang, lebih mungkin sore hari dan saat awan tebal
    $today = date('Y-m-d', $ts);
    if ($s['rainDay'] !== $today) {
        $s['rainDay'] = $today;
        $s['rainTotal'] = 0.0;
    }
    if ($s['rainLeft'] > 0) {
        $s['rainLeft'] -= $dt;
        $s['rainRate'] = clamp($s['rainRate'] + gauss(0.4), 0.2, 8);
        $s['rainTotal'] += $s['rainRate'] * $k;
        $s['cloud'] = max($s['cloud'], 0.75);
        if ($s['rainLeft'] <= 0) {
            $s['rainLeft'] = 0;
            $s['rainRate'] = 0.0;
        }
    } else {
        $pHour = ($h >= 13 && $h < 19) ? 0.02 : 0.004;  // peluang hujan dimulai per jam
        if ($s['cloud'] > 0.55)
            $pHour *= 3;
        if (mt_rand() / mt_getrandmax() < $pHour * $k) {
            $s['rainLeft'] = (int) rnd(10 * 60, 40 * 60);   // 10–40 menit
            $s['rainRate'] = rnd(0.5, 4.0);                // mm/jam (hujan ringan–sedang)
        }
    }
    $raining = $s['rainLeft'] > 0;

    // Suhu — dataran tinggi: ±17 °C subuh, ±26 °C siang
    $s['tempN'] = $s['tempN'] * 0.95 + gauss(0.08);
    $temp = 17.2 + 9.0 * $d + $s['tempN'] - 1.8 * $s['cloud'] * $sun - ($raining ? 2.0 : 0);
    $temp = clamp($temp, 15, 29);

    // Kelembapan — berbanding terbalik dengan suhu
    $s['humN'] = $s['humN'] * 0.95 + gauss(0.3);
    $hum = 95 - 28 * $d + $s['humN'] + 6 * $s['cloud'] + ($raining ? 7 : 0);
    $hum = clamp($hum, 52, 99);

    // Tekanan stasiun (±1.200 mdpl) + pasang-surut atmosfer semi-diurnal
    $s['presN'] = clamp($s['presN'] * 0.995 + gauss(0.02), -1.5, 1.5);
    $pres = 880.5 + 1.1 * cos(4 * M_PI * ($h - 10) / 24) + $s['presN'];

    // Angin — tenang malam hari, angin lembah siang-sore
    $s['windN'] = $s['windN'] * 0.7 + gauss(0.45);
    $wind = clamp(0.6 + 2.6 * $d + $s['windN'] + ($raining ? 1.2 : 0), 0, 9);
    $s['wdir'] = fmod($s['wdir'] + gauss(8) + (225 - $s['wdir']) * 0.01 + 360, 360);

    // Tinggi muka air (banjir) — kering, naik sedikit saat hujan
    $s['flood'] = 0.6 + ($s['flood'] - 0.6) * exp(-$k * 1.5) + ($raining ? $s['rainRate'] * $k * 1.2 : 0);
    $flood = clamp($s['flood'] + gauss(0.05), 0, 10);

    // Kelembapan tanah — perlahan mengering, naik saat hujan
    $s['soil'] += ($raining ? $s['rainRate'] * $k * 3.0 : -(0.02 + 0.08 * $sun) * $k);
    $s['soil'] = clamp($s['soil'], 28, 85);
    $soil = $s['soil'] + gauss(0.2);

    // Kemiringan (MPU) — stabil, hanya noise kecil
    $pitch = $s['pitchBase'] + gauss(0.02);
    $roll = $s['rollBase'] + gauss(0.02);

    // Cahaya & UV
    $cloudAtt = (1 - 0.7 * $s['cloud']) * ($raining ? 0.35 : 1);
    $lux = $sun > 0 ? max(0, 98000 * $sun ** 1.2 * $cloudAtt * (1 + gauss(0.04))) : 0;
    $uv = $sun > 0 ? clamp(11.5 * $sun ** 1.6 * (1 - 0.55 * $s['cloud']) * ($raining ? 0.4 : 1), 0, 13) : 0;

    // Baterai — terisi panel surya siang, berkurang malam
    $s['battery'] += $sun > 0.05 ? 9 * $sun * $cloudAtt * $k : -1.1 * $k;
    $s['battery'] = clamp($s['battery'], 20, 100);

    return [
        'temp' => round($temp, 2),
        'humidity' => round($hum, 1),
        'pressure' => round($pres, 1),
        'wind_speed' => round($wind, 1),
        'wind_direction' => round($s['wdir']),
        'rain' => round($s['rainTotal'], 1),
        'rain_rate' => round($s['rainRate'], 1),
        'flood' => round($flood, 1),
        'soil_moisture' => round($soil),
        'pitch' => round($pitch, 2),
        'roll' => round($roll, 2),
        'lux' => round($lux),
        'uv' => round($uv, 1),
        'battery' => round($s['battery'], 1),
    ];
}

/** Isi data simulasi dari data terakhir hingga sekarang. */
function generateUntilNow(PDO $pdo): void
{
    $pdo->exec('BEGIN IMMEDIATE');
    try {
        $now = time();
        $last = $pdo->query("SELECT MAX(ts) FROM readings WHERE source = 'dummy'")->fetchColumn();
        $last = $last === null ? null : (int) $last;
        $earliest = $now - (MAX_BACKFILL - 1) * SIM_INTERVAL;
        $start = $last === null ? $earliest : max($last + SIM_INTERVAL, $earliest);

        if ($start <= $now) {
            $state = metaGet($pdo, 'sim_state') ?? initialState();
            for ($t = $start; $t <= $now; $t += SIM_INTERVAL) {
                insertReading($pdo, $t, 'dummy', simulate($state, $t, SIM_INTERVAL));
            }
            metaSet($pdo, 'sim_state', $state);

            if (mt_rand(1, 50) === 1) {
                $pdo->prepare('DELETE FROM readings WHERE ts < ?')->execute([$now - RETENTION_DAYS * 86400]);
            }
        }
        $pdo->exec('COMMIT');
    } catch (Throwable $e) {
        $pdo->exec('ROLLBACK');
        throw $e;
    }
}

function respond(array $data, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// ===== ROUTER =====
try {
    $pdo = db();
    $action = $_GET['action'] ?? 'latest';

    switch ($action) {
        case 'latest':
            generateUntilNow($pdo);
            $row = $pdo->query("SELECT * FROM readings WHERE source = 'dummy' ORDER BY ts DESC LIMIT 1")->fetch();
            respond(['ok' => true, 'interval' => SIM_INTERVAL, 'data' => formatRow($row)]);

        case 'history':
            $source = ($_GET['source'] ?? 'dummy') === 'mqtt' ? 'mqtt' : 'dummy';
            $limit = max(1, min(1000, (int) ($_GET['limit'] ?? 100)));
            if ($source === 'dummy')
                generateUntilNow($pdo);
            $st = $pdo->prepare('SELECT * FROM (SELECT * FROM readings WHERE source = ? ORDER BY ts DESC LIMIT ?) ORDER BY ts ASC');
            $st->bindValue(1, $source);
            $st->bindValue(2, $limit, PDO::PARAM_INT);
            $st->execute();
            respond(['ok' => true, 'interval' => SIM_INTERVAL, 'data' => array_map('formatRow', $st->fetchAll())]);

        case 'store':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST')
                respond(['ok' => false, 'error' => 'Gunakan POST'], 405);
            $body = json_decode(file_get_contents('php://input') ?: '', true);
            if (!is_array($body))
                respond(['ok' => false, 'error' => 'Body JSON tidak valid'], 400);
            insertReading($pdo, time(), 'mqtt', $body);
            respond(['ok' => true]);

        default:
            respond(['ok' => false, 'error' => 'Action tidak dikenal'], 404);
    }
} catch (Throwable $e) {
    respond(['ok' => false, 'error' => $e->getMessage()], 500);
}
