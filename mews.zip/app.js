// ===== CONFIG =====
const CONFIG = {
    mqtt: {
        brokerUrl: 'wss://broker.hivemq.com:8884/mqtt',
        topic: 'weather_station/esp32s3/data',
        clientId: `mewscenter-${Math.random().toString(16).slice(2)}`,
    },
    api: {
        url: 'api/sensor.php',
        pollInterval: 15000,   // ms, polling data simulasi
        mqttTimeout: 10000,    // ms, tunggu payload MQTT sebelum beralih ke simulasi
    },
    bmkg: {
        weatherUrl: 'https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=11.17.07.2028',
        earthquakeUrl: 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json',
        shakemapBase: 'https://data.bmkg.go.id/DataMKG/TEWS/',
        weatherRefresh: 600000,
        earthquakeRefresh: 60000,
    },
    map: {
        lat: 4.7596528158,
        lon: 96.7751885943,
        zoom: 14,
    }
};

// ===== STATE =====
let sensorChart = null;
let currentChartType = 'temperature';
let sensorHistory = { labels: [], temperature: [], humidity: [], pressure: [] };
let previousSensorData = null;
let map = null;
let sensorMarker = null;
let mqttClient = null;
let dataMode = 'waiting';      // 'waiting' | 'mqtt' | 'dummy'
let dummyTimer = null;
let mqttWaitTimer = null;
let lastDummyTs = null;

// ===== CLOCK =====
function updateClock() {
    const now = new Date();
    const opts = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZone: 'Asia/Jakarta' };
    document.getElementById('liveClock').textContent = now.toLocaleTimeString('id-ID', opts) + ' WIB';
}
setInterval(updateClock, 1000);
updateClock();

// ===== MQTT SENSOR DATA =====
function connectMqtt() {
    if (mqttClient) return;
    setConnectionStatus('connecting', 'Menghubungkan...');
    mqttClient = mqtt.connect(CONFIG.mqtt.brokerUrl, { clientId: CONFIG.mqtt.clientId, clean: true, reconnectPeriod: 5000 });
    const client = mqttClient;
    // Saat mode simulasi aktif, status MQTT tidak menimpa badge simulasi
    const mqttStatus = (status, text) => { if (dataMode !== 'dummy') setConnectionStatus(status, text); };
    client.on('connect', () => client.subscribe(CONFIG.mqtt.topic, err => {
        if (err) { console.error('MQTT subscribe error:', err); mqttStatus('error', 'Gagal subscribe'); return; }
        if (dataMode === 'waiting') {
            mqttStatus('online', 'MQTT Online · Menunggu data');
            document.getElementById('sensorLastUpdate').textContent = 'Menunggu payload sensor...';
        }
    }));
    client.on('reconnect', () => mqttStatus('connecting', 'Menghubungkan...'));
    client.on('offline', () => mqttStatus('error', 'MQTT Offline'));
    client.on('error', err => console.error('MQTT error:', err));
    client.on('message', (topic, message) => {
        if (topic !== CONFIG.mqtt.topic) return;
        try {
            const data = JSON.parse(message.toString());
            switchToMqttMode();
            const vals = updateSensorCards(data);
            storeMqttReading(vals);
        } catch (err) { console.error('Payload MQTT tidak valid:', err); }
    });
}

// ===== SIMULATED DATA (SQLite via api/sensor.php) =====
async function startDummyMode() {
    if (dataMode !== 'waiting') return;
    dataMode = 'dummy';
    setConnectionStatus('dummy', 'ESP32 belum mengirim data');
    try {
        const res = await fetch(`${CONFIG.api.url}?action=history&limit=100`, { cache: 'no-store' });
        const json = await res.json();
        if (!json.ok) throw new Error(json.error);
        if (dataMode !== 'dummy') return;
        json.data.forEach(row => applyDummyRow(row));
    } catch (err) {
        console.error('Gagal memuat data:', err);
        setConnectionStatus('error', 'Simulasi gagal · cek XAMPP/PHP');
        document.getElementById('sensorLastUpdate').textContent = 'Buka via http://localhost/mews/ (bukan file://)';
    }
    if (dataMode === 'dummy') dummyTimer = setInterval(pollDummy, CONFIG.api.pollInterval);
}

async function pollDummy() {
    try {
        const res = await fetch(`${CONFIG.api.url}?action=latest`, { cache: 'no-store' });
        const json = await res.json();
        if (json.ok && dataMode === 'dummy') applyDummyRow(json.data);
    } catch (err) { console.error('Polling gagal:', err); }
}

function applyDummyRow(row) {
    const ts = new Date(row.ts);
    if (lastDummyTs && ts <= lastDummyTs) return;
    lastDummyTs = ts;
    updateSensorCards(row, ts);
}

function switchToMqttMode() {
    clearTimeout(mqttWaitTimer);
    if (dataMode === 'mqtt') return;
    if (dataMode === 'dummy') {
        clearInterval(dummyTimer);
        // bersihkan grafik agar data simulasi tidak tercampur data asli
        Object.values(sensorHistory).forEach(values => values.length = 0);
        previousSensorData = null;
    }
    dataMode = 'mqtt';
    setConnectionStatus('online', 'MQTT Live');
}

function storeMqttReading(v) {
    const body = {
        temp: v.temp, humidity: v.humidity, pressure: v.pressure, wind_speed: v.windSpeed,
        wind_direction: v.windDirection, rain: v.rain, flood: v.flood, soil_moisture: v.soilMoisture,
        pitch: v.pitch, roll: v.roll, lux: v.lux, uv: v.uv, battery: v.battery,
    };
    Object.keys(body).forEach(k => { if (!Number.isFinite(body[k])) delete body[k]; });
    fetch(`${CONFIG.api.url}?action=store`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }).catch(err => console.warn('Gagal menyimpan data MQTT:', err));
}

function updateSensorCards(data, dt = new Date()) {
    const readNumber = (paths) => {
        for (const path of paths) {
            const value = path.split('.').reduce((current, key) => current?.[key], data);
            const number = Number(value);
            if (value !== undefined && value !== null && Number.isFinite(number)) return number;
        }
        return NaN;
    };

    const vals = {
        temp: readNumber(['temp', 'temperature', 'bme280.temperature', 'bme280.temp', 'bme.temperature']),
        humidity: readNumber(['rh', 'humidity', 'bme280.humidity', 'bme.humidity']),
        pressure: readNumber(['pres', 'pressure', 'bme280.pressure', 'bme.pressure']),
        windSpeed: readNumber(['ws', 'wind.speed', 'wind.speed_ms', 'wind_speed']),
        windDirection: readNumber(['wd', 'wind.direction', 'wind.degrees', 'wind_direction']),
        rain: readNumber(['rain.mm', 'rain.amount', 'rain_mm', 'rain']),
        rainTotal: readNumber(['rain.total', 'rain.total_mm', 'rain_total']),
        flood: readNumber(['flood']),
        soilMoisture: readNumber(['soil.percent', 'soil.moisture', 'soil_moisture', 'percent']),
        pitch: readNumber(['pitch', 'mpu.pitch']),
        roll: readNumber(['roll', 'mpu.roll']),
        lux: readNumber(['lux']),
        uv: readNumber(['uv']),
        battery: readNumber(['batt', 'battery']),
    };

    setVal('sensorTemp', vals.temp, 2);
    setVal('sensorHumidity', vals.humidity, 1);
    setVal('sensorPressure', vals.pressure, 1);
    setVal('sensorWindSpeed', vals.windSpeed, 1);
    setVal('sensorWindDirection', vals.windDirection, 0);
    setVal('sensorRain', vals.rain, 1);
    setVal('sensorFlood', vals.flood, 1);
    setVal('sensorSoilMoisture', vals.soilMoisture, 0);
    setVal('sensorPitch', vals.pitch, 2);
    setVal('sensorRoll', vals.roll, 2);
    setVal('sensorLux', vals.lux, 0);
    setVal('sensorUv', vals.uv, 1);
    setVal('sensorBattery', vals.battery, 1);

    // bars
    setBar('barTemp', vals.temp, 0, 50);
    setBar('barHumidity', vals.humidity, 0, 100);
    setBar('barPressure', vals.pressure, 850, 1050);
    setBar('barWindSpeed', vals.windSpeed, 0, 20);
    setBar('barWindDirection', vals.windDirection, 0, 360);
    setBar('barRain', vals.rain, 0, 100);
    setBar('barFlood', vals.flood, 0, 10);
    setBar('barSoilMoisture', vals.soilMoisture, 0, 100);
    setBar('barPitch', vals.pitch, -3, 3);
    setBar('barRoll', vals.roll, -3, 3);
    setBar('barLux', vals.lux, 0, 100000);
    setBar('barUv', vals.uv, 0, 12);
    setBar('barBattery', vals.battery, 0, 100);

    // trends
    if (previousSensorData) {
        Object.keys(vals).forEach(key => {
            if (Number.isFinite(vals[key]) && Number.isFinite(previousSensorData[key])) {
                setTrend(`trend${key[0].toUpperCase()}${key.slice(1)}`, vals[key], previousSensorData[key]);
            }
        });
    }
    previousSensorData = vals;

    // last update
    document.getElementById('sensorLastUpdate').textContent =
        `${data.sid || 'Sensor'} · ${dt.toLocaleDateString('id-ID')} ${dt.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;
    updateSensorChart(vals, dt);
    return vals;
}

function setVal(id, val, decimals) {
    const el = document.getElementById(id);
    if (el && !isNaN(val)) el.textContent = val.toFixed(decimals);
}
function setBar(id, val, min, max) {
    const pct = Math.min(100, Math.max(0, ((val - min) / (max - min)) * 100));
    const el = document.getElementById(id);
    if (el) el.style.width = pct + '%';
}
function setTrend(id, curr, prev) {
    const el = document.getElementById(id);
    if (!el) return;
    const diff = curr - prev;
    if (Math.abs(diff) < 0.01) {
        el.textContent = '—'; el.className = 'sensor-trend stable';
    } else if (diff > 0) {
        el.textContent = '▲ ' + diff.toFixed(2); el.className = 'sensor-trend up';
    } else {
        el.textContent = '▼ ' + Math.abs(diff).toFixed(2); el.className = 'sensor-trend down';
    }
}

function setConnectionStatus(status, text) {
    const el = document.getElementById('connectionStatus');
    el.className = 'status-badge ' + status;
    el.querySelector('.status-text').textContent = text;
}

// ===== CHART =====
function initChart() {
    const ctx = document.getElementById('sensorChart').getContext('2d');
    sensorChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Suhu (°C)',
                data: [],
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                borderWidth: 2, tension: 0.4, fill: true,
                pointRadius: 0, pointHitRadius: 10,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.95)',
                    titleColor: '#f1f5f9', bodyColor: '#94a3b8',
                    borderColor: 'rgba(99, 102, 241, 0.3)', borderWidth: 1,
                    padding: 12, cornerRadius: 8,
                    titleFont: { family: 'Inter', weight: '600' },
                    bodyFont: { family: 'JetBrains Mono' },
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: { tooltipFormat: 'dd MMM yyyy HH:mm', displayFormats: { minute: 'HH:mm', hour: 'HH:mm' } },
                    grid: { color: 'rgba(255,255,255,0.04)' },
                    ticks: { color: '#64748b', font: { size: 10, family: 'JetBrains Mono' }, maxTicksLimit: 8 },
                },
                y: {
                    grid: { color: 'rgba(255,255,255,0.04)' },
                    ticks: { color: '#64748b', font: { size: 10, family: 'JetBrains Mono' } },
                }
            },
            interaction: { intersect: false, mode: 'index' },
            animation: { duration: 800, easing: 'easeInOutQuart' },
        }
    });
}

function updateSensorChart(data, timestamp) {
    sensorHistory.labels.push(timestamp);
    sensorHistory.temperature.push(data.temp);
    sensorHistory.humidity.push(data.humidity);
    sensorHistory.pressure.push(data.pressure);
    if (sensorHistory.labels.length > 100) Object.values(sensorHistory).forEach(values => values.shift());

    applyChartData(currentChartType);
}

function applyChartData(type) {
    if (!sensorChart) return;
    const chartConfig = {
        temperature: { label: 'Suhu (°C)', color: '#f59e0b', data: sensorHistory.temperature },
        humidity: { label: 'Kelembapan (%)', color: '#22d3ee', data: sensorHistory.humidity },
        pressure: { label: 'Tekanan (hPa)', color: '#8b5cf6', data: sensorHistory.pressure },
    };
    const c = chartConfig[type];
    sensorChart.data.labels = sensorHistory.labels;
    sensorChart.data.datasets[0].label = c.label;
    sensorChart.data.datasets[0].data = c.data;
    sensorChart.data.datasets[0].borderColor = c.color;
    sensorChart.data.datasets[0].backgroundColor = c.color + '1a';
    sensorChart.update();
}

document.querySelectorAll('.chart-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentChartType = btn.dataset.chart;
        applyChartData(currentChartType);
    });
});

// ===== MAP =====
function initMap() {
    map = L.map('map', { zoomControl: true, scrollWheelZoom: true }).setView([CONFIG.map.lat, CONFIG.map.lon], CONFIG.map.zoom);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
    }).addTo(map);

    // Main location marker
    const mainIcon = L.divIcon({
        className: 'main-marker',
        html: `<div style="position:relative;">
            <div style="width:20px;height:20px;background:linear-gradient(135deg,#22d3ee,#8b5cf6);border-radius:50%;border:3px solid #fff;box-shadow:0 0 20px rgba(34,211,238,0.5);"></div>
            <div style="position:absolute;top:-2px;left:-2px;width:24px;height:24px;border-radius:50%;border:2px solid rgba(34,211,238,0.4);animation:mapPulse 2s ease-out infinite;"></div>
        </div>`,
        iconSize: [20, 20], iconAnchor: [10, 10]
    });

    L.marker([CONFIG.map.lat, CONFIG.map.lon], { icon: mainIcon })
        .addTo(map)
        .bindPopup(`
            <div style="min-width:200px;">
                <div style="font-weight:700;font-size:1rem;margin-bottom:4px;">📍 Lampahan Timur</div>
                <div style="font-size:0.8rem;color:#94a3b8;line-height:1.4;">
                    Kec. Timang Gajah<br>
                    Kab. Bener Meriah, Aceh<br>
                    <span style="font-family:monospace;font-size:0.75rem;">
                        ${CONFIG.map.lat.toFixed(6)}°N, ${CONFIG.map.lon.toFixed(6)}°E
                    </span>
                </div>
            </div>
        `)
        .openPopup();

    // Add a translucent area circle (~1km radius)
    L.circle([CONFIG.map.lat, CONFIG.map.lon], {
        radius: 1000, color: '#8b5cf6', fillColor: '#8b5cf6',
        fillOpacity: 0.08, weight: 1.5, dashArray: '6, 4', opacity: 0.4,
    }).addTo(map);

    // Add pulse CSS
    const style = document.createElement('style');
    style.textContent = `@keyframes mapPulse { 0% { transform: scale(1); opacity: 1; } 100% { transform: scale(3); opacity: 0; } }`;
    document.head.appendChild(style);
}

// ===== BMKG WEATHER =====
async function fetchWeather() {
    try {
        const res = await fetch(CONFIG.bmkg.weatherUrl);
        if (!res.ok) throw new Error('Weather fetch failed');
        const data = await res.json();
        renderWeather(data);
    } catch (err) {
        console.error('BMKG Weather error:', err);
        document.getElementById('weatherGrid').innerHTML = '<p style="color:var(--accent-red);padding:1rem;">Gagal memuat data cuaca BMKG.</p>';
    }
}

function renderWeather(data) {
    const loc = data.lokasi;
    document.getElementById('weatherLocation').innerHTML =
        `📍 <strong>${loc.desa}</strong>, Kec. ${loc.kecamatan}, ${loc.kotkab}, ${loc.provinsi}`;

    const allForecasts = data.data[0].cuaca.flat();
    // Group by date
    const grouped = {};
    allForecasts.forEach(f => {
        const localDt = new Date(f.local_datetime.replace(' ', 'T'));
        const dateKey = localDt.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
        if (!grouped[dateKey]) grouped[dateKey] = [];
        grouped[dateKey].push({ ...f, localDt });
    });

    let html = '';
    for (const [day, forecasts] of Object.entries(grouped)) {
        html += `<div class="weather-day-group">
            <div class="weather-day-label">${day}</div>
            <div class="weather-cards">`;
        forecasts.forEach(f => {
            const time = f.localDt.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false });
            html += `
                <div class="weather-card">
                    <div class="weather-time">${time}</div>
                    <div class="weather-icon"><img src="${f.image}" alt="${f.weather_desc}" loading="lazy"></div>
                    <div class="weather-desc">${f.weather_desc}</div>
                    <div class="weather-temp">${f.t}<span>°C</span></div>
                    <div class="weather-details">
                        <span>💧${f.hu}%</span>
                        <span>💨${f.ws} km/j</span>
                    </div>
                </div>`;
        });
        html += `</div></div>`;
    }

    document.getElementById('weatherGrid').innerHTML = html;
}

// ===== BMKG EARTHQUAKE =====
async function fetchEarthquake() {
    try {
        const res = await fetch(CONFIG.bmkg.earthquakeUrl);
        if (!res.ok) throw new Error('Earthquake fetch failed');
        const data = await res.json();
        renderEarthquake(data);
    } catch (err) {
        console.error('BMKG Earthquake error:', err);
        document.getElementById('earthquakeContent').innerHTML = '<p style="color:var(--accent-red);padding:1rem;">Gagal memuat data gempa BMKG.</p>';
    }
}

function renderEarthquake(data) {
    const g = data.Infogempa.gempa;
    const mag = parseFloat(g.Magnitude);
    let magColor = 'var(--accent-green)';
    let magBg = 'rgba(16, 185, 129, 0.1)';
    let magBorder = 'rgba(16, 185, 129, 0.3)';
    if (mag >= 5) { magColor = 'var(--accent-red)'; magBg = 'rgba(239, 68, 68, 0.1)'; magBorder = 'rgba(239, 68, 68, 0.3)'; }
    else if (mag >= 3) { magColor = 'var(--accent-orange)'; magBg = 'rgba(245, 158, 11, 0.1)'; magBorder = 'rgba(245, 158, 11, 0.3)'; }

    const coords = g.Coordinates.split(',');
    const lat = parseFloat(coords[0]);
    const lon = parseFloat(coords[1]);

    // Add quake marker on map
    if (map) {
        const quakeIcon = L.divIcon({
            className: 'quake-marker',
            html: `<div style="width:16px;height:16px;background:${magColor};border-radius:50%;border:3px solid rgba(255,255,255,0.8);box-shadow:0 0 15px ${magColor};"></div>`,
            iconSize: [16, 16], iconAnchor: [8, 8]
        });
        L.marker([lat, lon], { icon: quakeIcon })
            .addTo(map)
            .bindPopup(`<b>🔴 Gempa M${g.Magnitude}</b><br>${g.Wilayah}<br>${g.Tanggal} ${g.Jam}`);
    }

    document.getElementById('earthquakeContent').innerHTML = `
        <div class="quake-main">
            <div class="quake-magnitude" style="background:${magBg};border-color:${magBorder};">
                <div class="quake-mag-value" style="color:${magColor};">${g.Magnitude}</div>
                <div class="quake-mag-label" style="color:${magColor};">Magnitudo</div>
            </div>
            <div class="quake-info">
                <div class="quake-info-row">
                    <span class="quake-info-icon">📍</span>
                    <div class="quake-info-text">
                        <div class="quake-info-label">Wilayah</div>
                        <div class="quake-info-value">${g.Wilayah}</div>
                    </div>
                </div>
                <div class="quake-info-row">
                    <span class="quake-info-icon">🕐</span>
                    <div class="quake-info-text">
                        <div class="quake-info-label">Waktu</div>
                        <div class="quake-info-value">${g.Tanggal} — ${g.Jam}</div>
                    </div>
                </div>
                <div class="quake-info-row">
                    <span class="quake-info-icon">📐</span>
                    <div class="quake-info-text">
                        <div class="quake-info-label">Koordinat & Kedalaman</div>
                        <div class="quake-info-value">${g.Lintang}, ${g.Bujur} — ${g.Kedalaman}</div>
                    </div>
                </div>
                <div class="quake-info-row">
                    <span class="quake-info-icon">⚠️</span>
                    <div class="quake-info-text">
                        <div class="quake-info-label">Potensi</div>
                        <div class="quake-info-value">${g.Potensi}</div>
                    </div>
                </div>
                ${g.Dirasakan ? `
                <div class="quake-felt">
                    <div class="quake-felt-title">🔔 Dirasakan</div>
                    ${g.Dirasakan}
                </div>` : ''}
            </div>
        </div>
        ${g.Shakemap ? `
        <div class="quake-shakemap">
            <img src="${CONFIG.bmkg.shakemapBase}${g.Shakemap}" alt="Shakemap" loading="lazy" onerror="this.parentElement.style.display='none'">
        </div>` : ''}
    `;
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    initChart();
    initMap();
    connectMqtt();
    // ?mode=dummy -> langsung mode simulasi (untuk demo)
    const forceDummy = new URLSearchParams(location.search).get('mode') === 'dummy';
    mqttWaitTimer = setTimeout(startDummyMode, forceDummy ? 0 : CONFIG.api.mqttTimeout);
    fetchWeather();
    fetchEarthquake();

    setInterval(fetchWeather, CONFIG.bmkg.weatherRefresh);
    setInterval(fetchEarthquake, CONFIG.bmkg.earthquakeRefresh);
});
